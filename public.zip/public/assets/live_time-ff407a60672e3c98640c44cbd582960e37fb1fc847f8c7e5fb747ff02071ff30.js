document.addEventListener("DOMContentLoaded", function() {
  
  //var startDate = new Date(''); 
  //var startDate= new Date('');
  var dataElement = document.getElementById("my-data").getAttribute("data-test");
  var startDate = new Date(dataElement);
  //var startDate = new Date("");
  //var startDate = new Date();
  var counterElement = document.getElementById("live-time-counter");

  console.log('greg',startDate)

  function updateCounter() {
    var currentTime = new Date();

    console.log('currentTime', currentTime) 
    console.log('startDate', startDate)

    var timePassed = currentTime - startDate;
    
    console.log('timePassed',timePassed)
    var days = Math.floor(timePassed / (1000 * 60 * 60 * 24));
    var hours = Math.floor((timePassed % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((timePassed % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((timePassed % (1000 * 60)) / 1000);

    console.log('hours',hours)
    console.log('seconds',seconds)
    console.log('minutes', minutes)
    counterElement.innerHTML = days + " days, " + hours + ":" + minutes + ":" + seconds;

    // Display leading zeros for single-digit hours, minutes, and seconds
    hours = hours.toString().padStart(2, '0');
    minutes = minutes.toString().padStart(2, '0');
    seconds = seconds.toString().padStart(2, '0');
    

    console.log(hours)
    console.log(seconds)
    console.log(minutes)
    counterElement.innerHTML = days + " days " + hours + " hours " + minutes + " minutes " + seconds + " seconds ";
  }

  setInterval(updateCounter, 1000);
});

